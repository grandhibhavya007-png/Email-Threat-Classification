import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI client if GEMINI_API_KEY is present
let aiClient: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  try {
    aiClient = new GoogleGenAI();
  } catch (err) {
    console.warn('Failed to initialize GoogleGenAI client:', err);
  }
}

// 1. Natural Language Executive Brief API
app.post('/api/executive-brief', async (req: Request, res: Response) => {
  try {
    const { datasetSummary, modelComparison, selectedModelMetrics } = req.body;

    if (aiClient && process.env.GEMINI_API_KEY) {
      const prompt = `You are a friendly, expert Machine Learning and Cybersecurity advisor writing for non-technical company executives (such as CEOs, HR heads, and team managers).

Explain the following machine learning results in plain English without complex mathematical equations. Use 3 short punchy bullet points and 1 clear takeaway:

Dataset Information:
- Total Emails Analyzed: ${datasetSummary?.totalEmails || 420}
- Malicious Threat Emails: ${datasetSummary?.threatPercentage || '45%'}
- Safe Routine Messages: ${datasetSummary?.routinePercentage || '55%'}
- Key Signals Observed: Typosquatted Domains, Urgency Panic Keywords, Executable Attachments, Link Density.

Model Performance (${selectedModelMetrics?.name || 'Logistic Regression'}):
- Overall Accuracy: ${selectedModelMetrics?.accuracy || '94.3%'}
- Threat Catch Rate (Recall): ${selectedModelMetrics?.recall || '95.1%'}
- False Alarm Rate: ${selectedModelMetrics?.falseAlarmRate || '4.2%'}
- Threats Missed: ${selectedModelMetrics?.missedThreats || '2'} out of ${selectedModelMetrics?.testThreats || '45'}

Please provide:
1. What the numbers mean in simple terms
2. The real-world business risk impact
3. Practical advice for non-technical employees`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      return res.json({
        summary: response.text,
        source: 'gemini-ai',
      });
    }

    // High quality deterministic fallback if no API key
    const fallback = `### Non-Technical Executive Overview
• **High Interception Capability:** The current model catches over ${(
      (selectedModelMetrics?.rawRecall || 0.95) * 100
    ).toFixed(0)}% of incoming phishing attacks before they reach employee inboxes.
• **Controlled False Alarms:** Less than ${(
      (1 - (selectedModelMetrics?.rawPrecision || 0.94)) * 100
    ).toFixed(0)}% of everyday workplace emails are mistakenly held for inspection.
• **Transparent Decision Making:** The system doesn't rely on opaque "magic"; every prediction is traced directly to observable traits such as suspicious sender domains, urgency triggers, and hidden links.

**Bottom-Line Advice:** Employees should continue using caution with emails demanding urgent password updates or payment revisions, especially when originating from external lookalike domains.`;

    return res.json({
      summary: fallback,
      source: 'rule-based',
    });
  } catch (error: any) {
    console.error('Error generating executive brief:', error);
    return res.status(500).json({
      error: 'Failed to generate summary',
      details: error.message,
    });
  }
});

// 2. Email Threat Investigation Copilot API
app.post('/api/explain-prediction', async (req: Request, res: Response) => {
  try {
    const { emailDetails, predictionResult } = req.body;

    if (aiClient && process.env.GEMINI_API_KEY) {
      const prompt = `You are a cybersecurity educator. Explain to a non-technical employee why an email was classified as "${predictionResult?.verdict}" with a risk score of ${predictionResult?.riskScore}/100.

Email Characteristics:
- Subject: "${emailDetails?.subject || 'N/A'}"
- Sender Address: "${emailDetails?.sender || 'N/A'}"
- Message Length: ${emailDetails?.message_length} characters
- Number of Links: ${emailDetails?.url_count}
- Number of Attachments: ${emailDetails?.attachment_count}
- Urgency Words Found: ${emailDetails?.urgency_keywords}
- Suspicious Domain Detected: ${emailDetails?.suspicious_domain ? 'YES' : 'NO'}
- Display Name Mismatch: ${emailDetails?.display_name_mismatch ? 'YES' : 'NO'}
- Executable File: ${emailDetails?.has_executable_attachment ? 'YES' : 'NO'}

Explain in 2-3 friendly sentences:
1. Why the system arrived at this verdict.
2. What specific clues the user should notice.
3. What specific safe action the user should take right now.`;

      const response = await aiClient.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt,
      });

      return res.json({
        explanation: response.text,
        source: 'gemini-ai',
      });
    }

    // High quality deterministic fallback
    let fallback = '';
    if ((predictionResult?.riskScore || 0) >= 70) {
      fallback = `⚠️ **Warning:** This email exhibits high-confidence markers of a cyber threat (${predictionResult?.riskScore}% risk). The combination of high urgency phrasing, lookalike sender details, and embedded links is typical of credential-harvesting phishing. **Action:** Do not click links or provide credentials. Flag this message to IT.`;
    } else if ((predictionResult?.riskScore || 0) >= 40) {
      fallback = `⚠️ **Caution:** This email shows moderate suspicion (${predictionResult?.riskScore}% risk). While it might be a legitimate broadcast or external invoice, multiple links and urgent phrasing warrant caution. **Action:** Double check the true sender address before opening attachments.`;
    } else {
      fallback = `✅ **Routine:** This message shows normal communication patterns (${100 - (predictionResult?.riskScore || 0)}% safe confidence) with standard link counts and legitimate sender credentials. **Action:** Safe to process as usual.`;
    }

    return res.json({
      explanation: fallback,
      source: 'rule-based',
    });
  } catch (error: any) {
    console.error('Error explaining prediction:', error);
    return res.status(500).json({
      error: 'Failed to explain prediction',
      details: error.message,
    });
  }
});

// Vite Middleware for Dev / Static Files for Prod
const isProd = process.env.NODE_ENV === 'production';

async function startServer() {
  if (!isProd) {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`DataSight ML Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
