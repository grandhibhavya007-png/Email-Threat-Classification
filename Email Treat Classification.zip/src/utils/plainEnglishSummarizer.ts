import { EvaluationMetrics, ModelComparisonResult } from '../types/dataset';

export interface MetricPlainExplanation {
  metric: string;
  scoreDisplay: string;
  nonTechnicalTranslation: string;
  realWorldRiskStory: string;
  badgeStatus: 'excellent' | 'good' | 'warning' | 'poor';
}

export function translateMetricsToPlainEnglish(
  metrics: EvaluationMetrics
): Record<string, MetricPlainExplanation> {
  const { accuracy, precision, recall, f1Score, rocAuc, confusionMatrix } = metrics;

  return {
    accuracy: {
      metric: 'Overall Accuracy',
      scoreDisplay: `${(accuracy * 100).toFixed(1)}%`,
      nonTechnicalTranslation:
        'Out of every 100 emails tested, how many did the system classify completely correctly (both safe and dangerous)?',
      realWorldRiskStory: `The model made the right call on ${(accuracy * 100).toFixed(
        1
      )}% of all simulated messages. While high, accuracy alone can be misleading if cyber threats are rare.`,
      badgeStatus: accuracy > 0.9 ? 'excellent' : accuracy > 0.8 ? 'good' : 'warning',
    },
    precision: {
      metric: 'Precision (False Alarm Filter)',
      scoreDisplay: `${(precision * 100).toFixed(1)}%`,
      nonTechnicalTranslation:
        'When the machine sounds the red siren and flags an email as an attack, how often is it REALLY an attack?',
      realWorldRiskStory: `When the system triggers an alert, it is correct ${(
        precision * 100
      ).toFixed(1)}% of the time. The remaining ${(100 - precision * 100).toFixed(
        1
      )}% were false alarms (innocent emails sent to quarantine).`,
      badgeStatus: precision > 0.9 ? 'excellent' : precision > 0.8 ? 'good' : 'warning',
    },
    recall: {
      metric: 'Recall / Detection Rate (Catch Rate)',
      scoreDisplay: `${(recall * 100).toFixed(1)}%`,
      nonTechnicalTranslation:
        'Out of ALL real attackers attempting to compromise your organization, what percentage did the system successfully catch?',
      realWorldRiskStory: `Crucial for cybersecurity! The model intercepted ${(
        recall * 100
      ).toFixed(1)}% of real threats. However, ${confusionMatrix.fn} dangerous threat(s) slipped past into user inboxes.`,
      badgeStatus: recall > 0.92 ? 'excellent' : recall > 0.8 ? 'good' : 'warning',
    },
    f1Score: {
      metric: 'F1-Score (The Balanced Score)',
      scoreDisplay: `${(f1Score * 100).toFixed(1)}%`,
      nonTechnicalTranslation:
        'The harmonic balance between avoiding false alarms (precision) and never missing real attacks (recall).',
      realWorldRiskStory:
        'A single number that prevents cherry-picking. It ensures the model is not achieving high precision by being too lazy, or high recall by screaming wolf at every email.',
      badgeStatus: f1Score > 0.9 ? 'excellent' : f1Score > 0.8 ? 'good' : 'warning',
    },
    rocAuc: {
      metric: 'ROC-AUC (Discrimination Power)',
      scoreDisplay: rocAuc.toFixed(3),
      nonTechnicalTranslation:
        'How reliably the model ranks a random dangerous email as riskier than a random safe email. 1.0 is clairvoyant; 0.5 is guessing like a flipped coin.',
      realWorldRiskStory: `With a score of ${rocAuc.toFixed(
        3
      )}, the system demonstrates stellar ability to separate malicious signals from workplace noise across all security thresholds.`,
      badgeStatus: rocAuc > 0.95 ? 'excellent' : rocAuc > 0.85 ? 'good' : 'warning',
    },
  };
}

export interface GlossaryItem {
  term: string;
  category: 'Metrics' | 'ML Concepts' | 'Cybersecurity';
  simpleDefinition: string;
  realWorldAnalogy: string;
}

export const NON_TECHNICAL_GLOSSARY: GlossaryItem[] = [
  {
    term: 'True Positive (TP)',
    category: 'Metrics',
    simpleDefinition: 'A dangerous phishing email that the model correctly caught and quarantined.',
    realWorldAnalogy: 'Airport security detecting a forbidden object in luggage. System protected you.',
  },
  {
    term: 'False Negative (FN)',
    category: 'Metrics',
    simpleDefinition: 'A malicious cyber attack that the model MISSED, letting it slip right into the employee inbox.',
    realWorldAnalogy: 'A security guard letting a burglar walk right in wearing a fake badge. The most dangerous failure in cybersecurity.',
  },
  {
    term: 'False Positive (FP)',
    category: 'Metrics',
    simpleDefinition: 'A harmless routine email mistakenly marked as spam or blocked.',
    realWorldAnalogy: 'A car alarm going off because a cat walked past it. Harmless, but annoying if frequent.',
  },
  {
    term: 'True Negative (TN)',
    category: 'Metrics',
    simpleDefinition: 'A routine, safe email that was correctly allowed into the inbox without interruption.',
    realWorldAnalogy: 'A regular employee scanning their badge and walking in smoothly without delay.',
  },
  {
    term: 'Logistic Regression',
    category: 'ML Concepts',
    simpleDefinition: 'A foundational statistical algorithm that weighs evidence (like links, sender domain) to calculate the 0-100% probability of an outcome.',
    realWorldAnalogy: 'A scale where each piece of suspicious evidence adds weighted grams onto the "Threat" side.',
  },
  {
    term: 'Decision Tree',
    category: 'ML Concepts',
    simpleDefinition: 'A transparent flowchart of Yes/No questions that leads to a final prediction.',
    realWorldAnalogy: 'A medical diagnostic checklist: "Does the patient have fever? Yes. Cough? Yes. -> Diagnose Flu."',
  },
  {
    term: 'K-Nearest Neighbors (KNN)',
    category: 'ML Concepts',
    simpleDefinition: 'Classifies a new email by finding the K most similar historical emails and letting them vote.',
    realWorldAnalogy: 'Asking your 5 closest neighbors what the weather will be like, and taking the majority vote.',
  },
  {
    term: 'Typosquatting',
    category: 'Cybersecurity',
    simpleDefinition: 'Registering web domains that look almost identical to real brand names (e.g. "m1crosoft.com" or "g00gle.com").',
    realWorldAnalogy: 'A counterfeit store setting up next door with a sign misspelled by one letter to trick passersby.',
  },
  {
    term: 'Data Leakage',
    category: 'ML Concepts',
    simpleDefinition: 'When information from the future or test set accidentally sneaks into the training process, giving false high scores.',
    realWorldAnalogy: 'A student accidentally seeing the test answer key before an exam. They look like a genius until they face a real unexpected test.',
  },
  {
    term: 'Gini Impurity',
    category: 'ML Concepts',
    simpleDefinition: 'A mathematical measure of chaos or disorder in a group of data.',
    realWorldAnalogy: 'A box of socks: if every sock is blue, impurity is 0. If it contains equal parts red, blue, green, and yellow, impurity is high.',
  },
];

export function generateAutomatedExecutiveSummary(
  models: ModelComparisonResult[],
  datasetSize: number,
  threatCount: number
): string {
  const bestModel = [...models].sort((a, b) => b.f1Score - a.f1Score)[0];
  const threatPercentage = ((threatCount / datasetSize) * 100).toFixed(1);

  return `Executive Summary for Leadership & Stakeholders:
We evaluated ${datasetSize} email communication records, in which ${threatPercentage}% represent active phishing and cyber threats. 
Among the foundational machine learning architectures tested, ${bestModel.name} emerged as the top-performing model, attaining an F1-Score of ${(
    bestModel.f1Score * 100
  ).toFixed(1)}% and an accuracy of ${(bestModel.accuracy * 100).toFixed(
    1
  )}%. 
Because this approach uses zero-cost, mathematically interpretable foundational ML, non-technical analysts can inspect exactly which features (such as typosquatted domains, panic language, and executable payloads) influenced each security verdict without relying on black-box opacity.`;
}
