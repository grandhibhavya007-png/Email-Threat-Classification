import {
  EmailRecord,
  EvaluationMetrics,
  FeatureImportance,
  FeatureKey,
  ModelAlgorithm,
  ModelComparisonResult,
  ThreatPredictionResult,
} from '../types/dataset';
import { FEATURE_METADATA } from '../data/emailDataset';

export const FEATURE_KEYS: FeatureKey[] = [
  'message_length',
  'url_count',
  'attachment_count',
  'urgency_keywords',
  'suspicious_domain',
  'display_name_mismatch',
  'has_executable_attachment',
];

export interface FeatureScalers {
  means: Record<FeatureKey, number>;
  stdDevs: Record<FeatureKey, number>;
}

// 1. Calculate Scalers for Normalization (Standardization)
export function fitScalers(dataset: EmailRecord[]): FeatureScalers {
  const means = {} as Record<FeatureKey, number>;
  const stdDevs = {} as Record<FeatureKey, number>;

  for (const key of FEATURE_KEYS) {
    const values = dataset.map((d) => d[key]);
    const mean = values.reduce((sum, v) => sum + v, 0) / values.length;
    const variance =
      values.reduce((sum, v) => sum + Math.pow(v - mean, 2), 0) / (values.length || 1);
    means[key] = mean;
    stdDevs[key] = Math.sqrt(variance) || 1; // avoid divide by zero
  }

  return { means, stdDevs };
}

// Transform a record into normalized vector
export function transformFeatures(
  record: Record<FeatureKey, number>,
  scalers: FeatureScalers
): number[] {
  return FEATURE_KEYS.map((key) => {
    const raw = record[key] ?? 0;
    return (raw - scalers.means[key]) / scalers.stdDevs[key];
  });
}

// 2. Stratified Train / Test Split
export function trainTestSplit(
  dataset: EmailRecord[],
  trainRatio = 0.75
): { train: EmailRecord[]; test: EmailRecord[] } {
  const routine = dataset.filter((d) => d.threat_class === 0);
  const threats = dataset.filter((d) => d.threat_class === 1);

  // Deterministic shuffle using seed-like step for consistency
  const shuffle = <T>(arr: T[]): T[] => {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.sin(i * 9973 + 13) * 10000) % (i + 1);
      const safeJ = (j + (i + 1)) % (i + 1);
      [copy[i], copy[safeJ]] = [copy[safeJ], copy[i]];
    }
    return copy;
  };

  const shuffledRoutine = shuffle(routine);
  const shuffledThreats = shuffle(threats);

  const trainRoutineCount = Math.floor(shuffledRoutine.length * trainRatio);
  const trainThreatCount = Math.floor(shuffledThreats.length * trainRatio);

  const train = [
    ...shuffledRoutine.slice(0, trainRoutineCount),
    ...shuffledThreats.slice(0, trainThreatCount),
  ];
  const test = [
    ...shuffledRoutine.slice(trainRoutineCount),
    ...shuffledThreats.slice(trainThreatCount),
  ];

  return { train, test };
}

// 3. Logistic Regression Implementation
export interface TrainedLogisticRegression {
  weights: Record<FeatureKey, number>;
  bias: number;
  predictProbability: (vector: number[]) => number;
}

export function trainLogisticRegression(
  trainData: EmailRecord[],
  scalers: FeatureScalers,
  epochs = 80,
  learningRate = 0.12,
  lambdaL2 = 0.001
): TrainedLogisticRegression {
  const numFeatures = FEATURE_KEYS.length;
  const weights = new Array(numFeatures).fill(0);
  let bias = 0;

  // Prepare normalized matrix
  const X: number[][] = trainData.map((d) => transformFeatures(d, scalers));
  const Y: number[] = trainData.map((d) => d.threat_class);
  const N = X.length;

  for (let epoch = 0; epoch < epochs; epoch++) {
    const gradWeights = new Array(numFeatures).fill(0);
    let gradBias = 0;

    for (let i = 0; i < N; i++) {
      let z = bias;
      for (let j = 0; j < numFeatures; j++) {
        z += weights[j] * X[i][j];
      }
      const pred = 1 / (1 + Math.exp(-Math.max(-20, Math.min(20, z))));
      const error = pred - Y[i];

      for (let j = 0; j < numFeatures; j++) {
        gradWeights[j] += error * X[i][j];
      }
      gradBias += error;
    }

    // Update weights with gradient descent and L2 penalty
    for (let j = 0; j < numFeatures; j++) {
      weights[j] -= learningRate * (gradWeights[j] / N + lambdaL2 * weights[j]);
    }
    bias -= learningRate * (gradBias / N);
  }

  const weightsMap = {} as Record<FeatureKey, number>;
  FEATURE_KEYS.forEach((key, idx) => {
    weightsMap[key] = weights[idx];
  });

  const predictProbability = (vector: number[]): number => {
    let z = bias;
    for (let j = 0; j < vector.length; j++) {
      z += weights[j] * vector[j];
    }
    return 1 / (1 + Math.exp(-Math.max(-20, Math.min(20, z))));
  };

  return { weights: weightsMap, bias, predictProbability };
}

// 4. Decision Tree Implementation
export interface DecisionTreeNode {
  featureIndex?: number;
  featureKey?: FeatureKey;
  threshold?: number;
  left?: DecisionTreeNode;
  right?: DecisionTreeNode;
  isLeaf: boolean;
  prediction?: number; // 0 or 1
  probability?: number;
  samples?: number;
  threatCount?: number;
  routineCount?: number;
}

export function trainDecisionTree(
  trainData: EmailRecord[],
  maxDepth = 4,
  minSamplesSplit = 4
): { root: DecisionTreeNode; predictProbability: (record: EmailRecord) => number } {
  function giniImpurity(labels: number[]): number {
    if (labels.length === 0) return 0;
    const p1 = labels.filter((l) => l === 1).length / labels.length;
    const p0 = 1 - p1;
    return 1 - (p0 * p0 + p1 * p1);
  }

  function buildTree(data: EmailRecord[], currentDepth: number): DecisionTreeNode {
    const labels = data.map((d) => d.threat_class);
    const threats = labels.filter((l) => l === 1).length;
    const routine = labels.length - threats;
    const prob = labels.length > 0 ? threats / labels.length : 0;

    if (
      currentDepth >= maxDepth ||
      data.length <= minSamplesSplit ||
      threats === 0 ||
      routine === 0
    ) {
      return {
        isLeaf: true,
        prediction: prob >= 0.5 ? 1 : 0,
        probability: prob,
        samples: data.length,
        threatCount: threats,
        routineCount: routine,
      };
    }

    let bestGini = 1.0;
    let bestFeatureIndex = -1;
    let bestThreshold = 0;
    let bestLeft: EmailRecord[] = [];
    let bestRight: EmailRecord[] = [];

    for (let fIdx = 0; fIdx < FEATURE_KEYS.length; fIdx++) {
      const fKey = FEATURE_KEYS[fIdx];
      const values = Array.from(new Set(data.map((d) => d[fKey]))).sort((a, b) => a - b);

      for (let i = 0; i < values.length - 1; i++) {
        const threshold = (values[i] + values[i + 1]) / 2;
        const left = data.filter((d) => d[fKey] <= threshold);
        const right = data.filter((d) => d[fKey] > threshold);

        if (left.length === 0 || right.length === 0) continue;

        const gini =
          (left.length / data.length) * giniImpurity(left.map((d) => d.threat_class)) +
          (right.length / data.length) * giniImpurity(right.map((d) => d.threat_class));

        if (gini < bestGini) {
          bestGini = gini;
          bestFeatureIndex = fIdx;
          bestThreshold = threshold;
          bestLeft = left;
          bestRight = right;
        }
      }
    }

    if (bestFeatureIndex === -1 || bestLeft.length === 0 || bestRight.length === 0) {
      return {
        isLeaf: true,
        prediction: prob >= 0.5 ? 1 : 0,
        probability: prob,
        samples: data.length,
        threatCount: threats,
        routineCount: routine,
      };
    }

    const featureKey = FEATURE_KEYS[bestFeatureIndex];
    return {
      isLeaf: false,
      featureIndex: bestFeatureIndex,
      featureKey,
      threshold: bestThreshold,
      samples: data.length,
      threatCount: threats,
      routineCount: routine,
      probability: prob,
      left: buildTree(bestLeft, currentDepth + 1),
      right: buildTree(bestRight, currentDepth + 1),
    };
  }

  const root = buildTree(trainData, 0);

  function predictProb(node: DecisionTreeNode, record: EmailRecord): number {
    if (node.isLeaf || !node.featureKey || node.threshold === undefined) {
      return node.probability ?? 0.5;
    }
    const val = record[node.featureKey] ?? 0;
    if (val <= node.threshold) {
      return node.left ? predictProb(node.left, record) : node.probability ?? 0;
    } else {
      return node.right ? predictProb(node.right, record) : node.probability ?? 1;
    }
  }

  return {
    root,
    predictProbability: (record: EmailRecord) => predictProb(root, record),
  };
}

// 5. K-Nearest Neighbors (KNN) Implementation
export function trainKNN(
  trainData: EmailRecord[],
  scalers: FeatureScalers,
  k = 5
): {
  predictProbability: (vector: number[]) => { prob: number; neighbors: EmailRecord[] };
} {
  const trainVectors = trainData.map((d) => ({
    record: d,
    vector: transformFeatures(d, scalers),
  }));

  const predictProbability = (vector: number[]) => {
    const distances = trainVectors.map(({ record, vector: tVec }) => {
      let sumDist = 0;
      for (let i = 0; i < vector.length; i++) {
        sumDist += Math.pow(vector[i] - tVec[i], 2);
      }
      return { record, distance: Math.sqrt(sumDist) };
    });

    distances.sort((a, b) => a.distance - b.distance);
    const topK = distances.slice(0, k);
    const threatCount = topK.filter((item) => item.record.threat_class === 1).length;
    return {
      prob: threatCount / k,
      neighbors: topK.map((i) => i.record),
    };
  };

  return { predictProbability };
}

// 6. Metrics & Confusion Matrix Calculation
export function evaluatePredictions(
  yTrue: number[],
  yProbs: number[],
  threshold = 0.5
): EvaluationMetrics {
  let tp = 0;
  let fp = 0;
  let tn = 0;
  let fn = 0;

  for (let i = 0; i < yTrue.length; i++) {
    const actual = yTrue[i];
    const predicted = yProbs[i] >= threshold ? 1 : 0;

    if (actual === 1 && predicted === 1) tp++;
    else if (actual === 0 && predicted === 1) fp++;
    else if (actual === 0 && predicted === 0) tn++;
    else if (actual === 1 && predicted === 0) fn++;
  }

  const total = tp + fp + tn + fn || 1;
  const accuracy = (tp + tn) / total;
  const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
  const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
  const f1Score =
    precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

  // Compute ROC-AUC using trapezoidal rule across 50 cutoff thresholds
  const rocPoints: { fpr: number; tpr: number }[] = [];
  const thresholds = Array.from({ length: 51 }, (_, idx) => idx / 50);

  for (const t of thresholds) {
    let tTp = 0;
    let tFp = 0;
    let tTn = 0;
    let tFn = 0;

    for (let i = 0; i < yTrue.length; i++) {
      const pred = yProbs[i] >= t ? 1 : 0;
      if (yTrue[i] === 1 && pred === 1) tTp++;
      else if (yTrue[i] === 0 && pred === 1) tFp++;
      else if (yTrue[i] === 0 && pred === 0) tTn++;
      else if (yTrue[i] === 1 && pred === 0) tFn++;
    }

    const tpr = tTp + tFn > 0 ? tTp / (tTp + tFn) : 0;
    const fpr = tFp + tTn > 0 ? tFp / (tFp + tTn) : 0;
    rocPoints.push({ fpr, tpr });
  }

  // Sort by fpr ascending
  rocPoints.sort((a, b) => a.fpr - b.fpr || a.tpr - b.tpr);

  let rocAuc = 0;
  for (let i = 0; i < rocPoints.length - 1; i++) {
    const width = rocPoints[i + 1].fpr - rocPoints[i].fpr;
    const avgHeight = (rocPoints[i + 1].tpr + rocPoints[i].tpr) / 2;
    rocAuc += width * avgHeight;
  }
  // Clamp AUC between 0.5 and 1.0
  rocAuc = Math.max(0.5, Math.min(1.0, Math.abs(rocAuc)));

  return {
    accuracy,
    precision,
    recall,
    f1Score,
    rocAuc,
    confusionMatrix: { tp, fp, tn, fn },
    testSetSize: yTrue.length,
    trainSetSize: 0,
  };
}

// 7. Benchmark and Compare All Foundational Methods for Capstone
export function compareFoundationalModels(
  trainData: EmailRecord[],
  testData: EmailRecord[],
  scalers: FeatureScalers
): ModelComparisonResult[] {
  const yTrueTest = testData.map((d) => d.threat_class);

  // 1. Logistic Regression
  const startLog = performance.now();
  const logModel = trainLogisticRegression(trainData, scalers);
  const logProbs = testData.map((d) =>
    logModel.predictProbability(transformFeatures(d, scalers))
  );
  const logTime = Math.max(1, Math.round(performance.now() - startLog));
  const logMetrics = evaluatePredictions(yTrueTest, logProbs);

  // 2. Decision Tree
  const startTree = performance.now();
  const treeModel = trainDecisionTree(trainData, 4);
  const treeProbs = testData.map((d) => treeModel.predictProbability(d));
  const treeTime = Math.max(1, Math.round(performance.now() - startTree));
  const treeMetrics = evaluatePredictions(yTrueTest, treeProbs);

  // 3. K-Nearest Neighbors
  const startKnn = performance.now();
  const knnModel = trainKNN(trainData, scalers, 5);
  const knnProbs = testData.map(
    (d) => knnModel.predictProbability(transformFeatures(d, scalers)).prob
  );
  const knnTime = Math.max(1, Math.round(performance.now() - startKnn));
  const knnMetrics = evaluatePredictions(yTrueTest, knnProbs);

  return [
    {
      algorithm: 'logistic_regression',
      name: 'Logistic Regression',
      accuracy: logMetrics.accuracy,
      precision: logMetrics.precision,
      recall: logMetrics.recall,
      f1Score: logMetrics.f1Score,
      rocAuc: logMetrics.rocAuc,
      trainingTimeMs: logTime,
      interpretability: 'Very High',
      suitabilityNote:
        'Zero runtime latency, directly inspectable linear coefficients, calibrated probabilities. Excellent for baseline.',
    },
    {
      algorithm: 'decision_tree',
      name: 'Decision Tree (CART)',
      accuracy: treeMetrics.accuracy,
      precision: treeMetrics.precision,
      recall: treeMetrics.recall,
      f1Score: treeMetrics.f1Score,
      rocAuc: treeMetrics.rocAuc,
      trainingTimeMs: treeTime,
      interpretability: 'Very High',
      suitabilityNote:
        'Visual flowchart rules easily understood by non-technical security teams without mathematical training.',
    },
    {
      algorithm: 'knn',
      name: 'K-Nearest Neighbors (k=5)',
      accuracy: knnMetrics.accuracy,
      precision: knnMetrics.precision,
      recall: knnMetrics.recall,
      f1Score: knnMetrics.f1Score,
      rocAuc: knnMetrics.rocAuc,
      trainingTimeMs: knnTime,
      interpretability: 'Moderate',
      suitabilityNote:
        'Non-parametric and good for clustering similar attack campaigns, but requires storing all training samples.',
    },
  ];
}

// 8. Explainability & Feature Contribution Breakdown
export function computeFeatureContributions(
  record: Record<FeatureKey, number>,
  weights: Record<FeatureKey, number>,
  scalers: FeatureScalers
): ThreatPredictionResult['featureContributions'] {
  const normVec = transformFeatures(record, scalers);

  return FEATURE_KEYS.map((key, idx) => {
    const rawVal = record[key];
    const weight = weights[key] || 0;
    const normVal = normVec[idx];
    const impact = normVal * weight;
    const meta = FEATURE_METADATA[key];

    let explanation = '';
    const isHighRisk = impact > 0.4 || (key === 'suspicious_domain' && rawVal === 1);

    if (key === 'suspicious_domain') {
      explanation =
        rawVal === 1
          ? 'Sender domain is flagged as typosquatted or external spoof (Huge threat signal).'
          : 'Sender domain matches trusted corporate records.';
    } else if (key === 'urgency_keywords') {
      explanation =
        rawVal > 2
          ? `Contains ${rawVal} high-stress panic words intended to rush the reader.`
          : 'Low or no urgency triggers detected.';
    } else if (key === 'has_executable_attachment') {
      explanation =
        rawVal === 1
          ? 'Dangerous attachment format (.exe/.zip) often containing malicious payloads.'
          : 'Standard safe attachments or none.';
    } else if (key === 'url_count') {
      explanation =
        rawVal >= 3
          ? `Contains ${rawVal} links, significantly higher than average routine communications.`
          : 'Normal link density.';
    } else if (key === 'display_name_mismatch') {
      explanation =
        rawVal === 1
          ? 'Sender display name pretends to be trusted personnel, but underlying address differs.'
          : 'Display name matches sender address.';
    } else if (key === 'message_length') {
      explanation =
        rawVal < 350
          ? 'Abnormally short message demanding immediate off-platform action.'
          : 'Standard body text length.';
    } else {
      explanation = `${meta.label} value of ${rawVal} ${meta.unit}.`;
    }

    return {
      feature: key,
      label: meta.label,
      value: rawVal,
      contributionScore: Math.round(impact * 20), // normalized impact percentage
      isHighRisk,
      explanation,
    };
  }).sort((a, b) => Math.abs(b.contributionScore) - Math.abs(a.contributionScore));
}

// 9. Single Prediction with Plain-English Verdict
export function predictSingleEmail(
  record: Record<FeatureKey, number>,
  logModel: TrainedLogisticRegression,
  scalers: FeatureScalers
): ThreatPredictionResult {
  const normVector = transformFeatures(record, scalers);
  const prob = logModel.predictProbability(normVector);
  const riskScore = Math.round(prob * 100);

  let verdict: 'Routine / Safe' | 'Suspicious' | 'Critical Threat' = 'Routine / Safe';
  if (riskScore >= 75) {
    verdict = 'Critical Threat';
  } else if (riskScore >= 40) {
    verdict = 'Suspicious';
  }

  const featureContributions = computeFeatureContributions(record, logModel.weights, scalers);

  // Generate plain English natural summary
  const topRisks = featureContributions.filter((c) => c.isHighRisk);
  let naturalSummary = '';
  let suggestedAction = '';

  if (verdict === 'Critical Threat') {
    naturalSummary = `This email is flagged as a Critical Threat with ${riskScore}% calculated attack probability. `;
    if (topRisks.length > 0) {
      naturalSummary += `The primary danger signals are: ${topRisks
        .map((r) => r.label.toLowerCase())
        .join(', ')}.`;
    }
    suggestedAction =
      'Isolate this message immediately. Do not click any links or open attachments. Report to your Security Operations Center.';
  } else if (verdict === 'Suspicious') {
    naturalSummary = `This email exhibits ambiguous characteristics with a ${riskScore}% caution score. While not definitely malicious, it contains irregularities like ${
      topRisks.length > 0 ? topRisks[0].label : 'higher-than-average link density'
    }.`;
    suggestedAction =
      'Verify the sender through a secondary channel (e.g. phone call or Slack message) before opening attachments.';
  } else {
    naturalSummary = `This email is classified as Routine and Safe (${100 - riskScore}% confidence). It aligns with normal workplace communications and contains no high-risk markers.`;
    suggestedAction = 'Safe to read and process normally according to corporate guidelines.';
  }

  return {
    probability: prob,
    riskScore,
    predictedClass: prob >= 0.5 ? 1 : 0,
    verdict,
    confidence: Math.round(Math.max(prob, 1 - prob) * 100),
    featureContributions,
    naturalSummary,
    suggestedAction,
  };
}
