import React, { useState } from 'react';
import { NON_TECHNICAL_GLOSSARY, GlossaryItem } from '../utils/plainEnglishSummarizer';
import { X, Search, BookOpen, Lightbulb } from 'lucide-react';

interface NonTechnicalGlossaryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NonTechnicalGlossaryModal: React.FC<NonTechnicalGlossaryModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('All');

  if (!isOpen) return null;

  const categories = ['All', 'Metrics', 'ML Concepts', 'Cybersecurity'];

  const filteredItems = NON_TECHNICAL_GLOSSARY.filter((item) => {
    const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
    const q = search.toLowerCase();
    const matchesSearch =
      item.term.toLowerCase().includes(q) ||
      item.simpleDefinition.toLowerCase().includes(q) ||
      item.realWorldAnalogy.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400">
              <BookOpen className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">
                Plain-English Machine Learning Glossary
              </h3>
              <p className="text-xs text-slate-400">
                Complex data science & cybersecurity terms translated for non-technical users
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Controls */}
        <div className="p-4 border-b border-slate-800 bg-slate-950/50 flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search glossary terms or analogies..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex gap-1.5 w-full sm:w-auto overflow-x-auto text-xs">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1 rounded-lg font-medium transition ${
                  activeCategory === cat
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Content List */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-3 divide-y divide-slate-800/50">
          {filteredItems.map((item, idx) => (
            <div key={item.term} className={idx > 0 ? 'pt-3' : ''}>
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-white text-sm">{item.term}</span>
                <span className="text-[10px] uppercase font-semibold px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700">
                  {item.category}
                </span>
              </div>
              <p className="text-xs text-slate-300">{item.simpleDefinition}</p>
              <div className="mt-2 p-2.5 rounded-lg bg-blue-950/30 border border-blue-800/40 text-xs text-blue-200 flex items-start gap-2">
                <Lightbulb className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-white">Real-World Analogy:</strong>{' '}
                  {item.realWorldAnalogy}
                </div>
              </div>
            </div>
          ))}
          {filteredItems.length === 0 && (
            <div className="text-center py-8 text-xs text-slate-400">
              No glossary entries found matching &quot;{search}&quot;.
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 bg-slate-950 text-right">
          <button
            onClick={onClose}
            className="text-xs font-semibold px-4 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
          >
            Close Glossary
          </button>
        </div>
      </div>
    </div>
  );
};
