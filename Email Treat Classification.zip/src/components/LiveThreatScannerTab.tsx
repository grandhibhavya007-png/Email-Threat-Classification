import React, { useState, useEffect } from 'react';
import { FeatureKey, ThreatPredictionResult } from '../types/dataset';
import { FEATURE_METADATA } from '../data/emailDataset';
import {
  FeatureScalers,
  TrainedLogisticRegression,
  predictSingleEmail,
} from '../utils/mlEngine';
import {
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Sparkles,
  Info,
  CheckCircle2,
  RefreshCw,
  Sliders,
  Send,
  HelpCircle,
} from 'lucide-react';

interface LiveThreatScannerTabProps {
  logisticModel: TrainedLogisticRegression;
  scalers: FeatureScalers;
}

const PRESET_SCENARIOS = [
  {
    name: '🚨 Urgent CEO Wire Scam',
    type: 'threat',
    subject: 'CONFIDENTIAL: Urgent offshore wire transfer needed by 2 PM',
    sender: 'ceo.office.mobile92@gmail.com',
    values: {
      message_length: 220,
      url_count: 1,
      attachment_count: 0,
      urgency_keywords: 6,
      suspicious_domain: 1,
      display_name_mismatch: 1,
      has_executable_attachment: 0,
    },
  },
  {
    name: '🚨 Password Reset Spoof',
    type: 'threat',
    subject: 'Microsoft 365: Your password expires in 15 minutes. Verify now',
    sender: 'it-security@m1crosoft-support-verify.com',
    values: {
      message_length: 450,
      url_count: 4,
      attachment_count: 0,
      urgency_keywords: 5,
      suspicious_domain: 1,
      display_name_mismatch: 1,
      has_executable_attachment: 0,
    },
  },
  {
    name: '🚨 Overdue Invoice (.ZIP Malware)',
    type: 'threat',
    subject: 'OVERDUE INVOICE #89421 - Immediate remittance advice attached',
    sender: 'accounting@vendor-fastbilling.top',
    values: {
      message_length: 380,
      url_count: 2,
      attachment_count: 1,
      urgency_keywords: 4,
      suspicious_domain: 1,
      display_name_mismatch: 0,
      has_executable_attachment: 1,
    },
  },
  {
    name: '🛡️ Team Planning Sync',
    type: 'safe',
    subject: 'Sprint 25 Planning Notes & Jira Board links for tomorrow',
    sender: 'sarah.pm@internal-corp.org',
    values: {
      message_length: 980,
      url_count: 2,
      attachment_count: 0,
      urgency_keywords: 0,
      suspicious_domain: 0,
      display_name_mismatch: 0,
      has_executable_attachment: 0,
    },
  },
  {
    name: '🛡️ HR Benefits Enrollment',
    type: 'safe',
    subject: 'Annual Open Enrollment Window: Summary of Health Benefits PDF',
    sender: 'benefits@internal-corp.org',
    values: {
      message_length: 1650,
      url_count: 1,
      attachment_count: 1,
      urgency_keywords: 1,
      suspicious_domain: 0,
      display_name_mismatch: 0,
      has_executable_attachment: 0,
    },
  },
];

export const LiveThreatScannerTab: React.FC<LiveThreatScannerTabProps> = ({
  logisticModel,
  scalers,
}) => {
  const [subject, setSubject] = useState(PRESET_SCENARIOS[0].subject);
  const [sender, setSender] = useState(PRESET_SCENARIOS[0].sender);
  const [inputValues, setInputValues] = useState<Record<FeatureKey, number>>(
    PRESET_SCENARIOS[0].values
  );
  const [prediction, setPrediction] = useState<ThreatPredictionResult | null>(null);
  const [aiDebrief, setAiDebrief] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [showHelper, setShowHelper] = useState(true);

  // Re-predict whenever inputs change
  useEffect(() => {
    const result = predictSingleEmail(inputValues, logisticModel, scalers);
    setPrediction(result);
    setAiDebrief(null); // clear old AI debrief
  }, [inputValues, logisticModel, scalers]);

  const handleSelectPreset = (preset: (typeof PRESET_SCENARIOS)[0]) => {
    setSubject(preset.subject);
    setSender(preset.sender);
    setInputValues(preset.values);
  };

  const handleFeatureChange = (key: FeatureKey, val: number) => {
    setInputValues((prev) => ({ ...prev, [key]: val }));
  };

  const handleAskAiDebrief = async () => {
    if (!prediction) return;
    setLoadingAi(true);
    try {
      const res = await fetch('/api/explain-prediction', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          emailDetails: {
            subject,
            sender,
            ...inputValues,
          },
          predictionResult: prediction,
        }),
      });
      const data = await res.json();
      setAiDebrief(data.explanation || data.error);
    } catch (err) {
      console.error(err);
      setAiDebrief(
        '⚠️ Notice: Unable to reach AI debrief service. The model verdict above remains 100% active and accurate.'
      );
    } finally {
      setLoadingAi(false);
    }
  };

  if (!prediction) return null;

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-900/40 via-indigo-950/40 to-slate-900 border border-blue-800/40 rounded-2xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-blue-400 font-semibold text-sm mb-1">
              <ShieldAlert className="w-4 h-4" />
              <span>Step 05 of 05 • Prototype Application & What-If Testing</span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Live Email Threat Scanner & Explainable AI Sandbox
            </h2>
            <p className="text-sm text-slate-300 max-w-3xl mt-1">
              Test new email observations interactively. The prototype validates measurable message characteristics, applies the exact same normalization scalers as training, and reveals why the model flagged the email.
            </p>
          </div>
          <button
            onClick={() => setShowHelper(!showHelper)}
            className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 transition shrink-0"
          >
            <HelpCircle className="w-4 h-4" />
            <span>{showHelper ? 'Hide Tips' : 'How to Use'}</span>
          </button>
        </div>

        {showHelper && (
          <div className="mt-4 pt-4 border-t border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-300">
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
              <span className="font-semibold text-white block mb-1">1. Pick a Scenario Preset</span>
              Choose one of the pre-loaded attack or safe email examples below for instant testing.
            </div>
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
              <span className="font-semibold text-white block mb-1">2. Tweak What-If Sliders</span>
              Watch how changing link count, urgency triggers, or domain flags immediately shifts the threat gauge.
            </div>
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
              <span className="font-semibold text-white block mb-1">3. Inspect the &apos;Why&apos;</span>
              No black-box mystery: see the transparent waterfall of feature contributions explaining the verdict.
            </div>
          </div>
        )}
      </div>

      {/* Quick Scenario Preset Buttons */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm space-y-2">
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
          One-Click Test Scenarios:
        </span>
        <div className="flex flex-wrap gap-2">
          {PRESET_SCENARIOS.map((scenario) => {
            const isSelected = subject === scenario.subject;
            return (
              <button
                key={scenario.name}
                onClick={() => handleSelectPreset(scenario)}
                className={`text-xs px-3 py-2 rounded-xl font-medium border transition ${
                  isSelected
                    ? 'bg-blue-600 text-white border-blue-500 shadow-sm'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700 hover:bg-slate-800'
                }`}
              >
                {scenario.name}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Inputs (Left) and Prediction Output (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Email Details & Measurable Characteristics (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-5">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Measurable Email Characteristics (Inputs)
            </h3>
          </div>

          {/* Email Header Preview */}
          <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
            <div>
              <span className="text-slate-400 font-medium">Subject:</span>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-white text-xs mt-1 focus:outline-none focus:border-blue-500"
              />
            </div>
            <div>
              <span className="text-slate-400 font-medium">Sender Address:</span>
              <input
                type="text"
                value={sender}
                onChange={(e) => setSender(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1 text-white text-xs mt-1 font-mono focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          {/* Continuous Numeric Sliders */}
          <div className="space-y-4 pt-2 border-t border-slate-800">
            {/* Message Length */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-200">
                  {FEATURE_METADATA.message_length.label}:
                </span>
                <span className="font-mono text-blue-400 font-bold">
                  {inputValues.message_length} {FEATURE_METADATA.message_length.unit}
                </span>
              </div>
              <input
                type="range"
                min="50"
                max="4500"
                step="50"
                value={inputValues.message_length}
                onChange={(e) =>
                  handleFeatureChange('message_length', parseInt(e.target.value, 10))
                }
                className="w-full accent-blue-500"
              />
              <span className="text-[11px] text-slate-500">
                Short emails (&lt;300 chars) are typical of urgent &quot;Click now&quot; lures.
              </span>
            </div>

            {/* URL Count */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-200">
                  {FEATURE_METADATA.url_count.label}:
                </span>
                <span className="font-mono text-blue-400 font-bold">
                  {inputValues.url_count} {FEATURE_METADATA.url_count.unit}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="12"
                step="1"
                value={inputValues.url_count}
                onChange={(e) =>
                  handleFeatureChange('url_count', parseInt(e.target.value, 10))
                }
                className="w-full accent-blue-500"
              />
              <span className="text-[11px] text-slate-500">
                Number of clickable links embedded in the body.
              </span>
            </div>

            {/* Attachment Count */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-200">
                  {FEATURE_METADATA.attachment_count.label}:
                </span>
                <span className="font-mono text-blue-400 font-bold">
                  {inputValues.attachment_count} {FEATURE_METADATA.attachment_count.unit}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="5"
                step="1"
                value={inputValues.attachment_count}
                onChange={(e) =>
                  handleFeatureChange('attachment_count', parseInt(e.target.value, 10))
                }
                className="w-full accent-blue-500"
              />
            </div>

            {/* Urgency Trigger Keywords */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-200">
                  {FEATURE_METADATA.urgency_keywords.label}:
                </span>
                <span
                  className={`font-mono font-bold ${
                    inputValues.urgency_keywords > 2 ? 'text-rose-400' : 'text-blue-400'
                  }`}
                >
                  {inputValues.urgency_keywords} trigger words
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="10"
                step="1"
                value={inputValues.urgency_keywords}
                onChange={(e) =>
                  handleFeatureChange('urgency_keywords', parseInt(e.target.value, 10))
                }
                className="w-full accent-blue-500"
              />
              <span className="text-[11px] text-slate-500">
                Words like: Urgent, Suspended, Verify, Password, Wire, Overdue.
              </span>
            </div>
          </div>

          {/* Binary Indicators (Toggles) */}
          <div className="space-y-3 pt-3 border-t border-slate-800">
            <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">
              Sender & Technical Indicators:
            </span>

            {/* Suspicious Domain */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  Suspicious / Typosquatted Domain
                </div>
                <div className="text-[11px] text-slate-400">
                  E.g. m1crosoft.com, paypa1.com, or random .xyz domain
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleFeatureChange(
                    'suspicious_domain',
                    inputValues.suspicious_domain ? 0 : 1
                  )
                }
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  inputValues.suspicious_domain
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {inputValues.suspicious_domain ? 'YES (Spoofed)' : 'NO (Legit)'}
              </button>
            </div>

            {/* Display Name Mismatch */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  Display Name Mismatch
                </div>
                <div className="text-[11px] text-slate-400">
                  Name claims to be CEO / IT Support, but address is a free webmail
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleFeatureChange(
                    'display_name_mismatch',
                    inputValues.display_name_mismatch ? 0 : 1
                  )
                }
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  inputValues.display_name_mismatch
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {inputValues.display_name_mismatch ? 'YES (Mismatch)' : 'NO (Matches)'}
              </button>
            </div>

            {/* Executable File */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800">
              <div>
                <div className="text-xs font-semibold text-slate-200">
                  High-Risk Dangerous File Type
                </div>
                <div className="text-[11px] text-slate-400">
                  Includes .exe, .scr, .zip, .vbs, or nested archives
                </div>
              </div>
              <button
                type="button"
                onClick={() =>
                  handleFeatureChange(
                    'has_executable_attachment',
                    inputValues.has_executable_attachment ? 0 : 1
                  )
                }
                className={`px-3 py-1 rounded-lg text-xs font-bold transition ${
                  inputValues.has_executable_attachment
                    ? 'bg-rose-600 text-white'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {inputValues.has_executable_attachment ? 'YES (.exe/.zip)' : 'NO (Normal file)'}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Prediction Verdict & Explainability (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Main Verdict Card */}
          <div
            className={`border rounded-2xl p-6 shadow-md transition-all ${
              prediction.verdict === 'Critical Threat'
                ? 'bg-gradient-to-b from-rose-950/60 to-slate-900 border-rose-500/50 shadow-rose-950/50'
                : prediction.verdict === 'Suspicious'
                ? 'bg-gradient-to-b from-amber-950/60 to-slate-900 border-amber-500/50 shadow-amber-950/50'
                : 'bg-gradient-to-b from-emerald-950/60 to-slate-900 border-emerald-500/50 shadow-emerald-950/50'
            }`}
          >
            <div className="text-center space-y-3">
              {/* Circular Risk Score Gauge */}
              <div className="relative inline-flex items-center justify-center">
                <svg className="w-32 h-32 transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="54"
                    stroke="#1e293b"
                    strokeWidth="10"
                    fill="transparent"
                  />
                  <circle
                    cx="64"
                    cy="64"
                    r="54"
                    stroke={
                      prediction.verdict === 'Critical Threat'
                        ? '#f43f5e'
                        : prediction.verdict === 'Suspicious'
                        ? '#f59e0b'
                        : '#10b981'
                    }
                    strokeWidth="10"
                    strokeDasharray={339.29}
                    strokeDashoffset={339.29 - (339.29 * prediction.riskScore) / 100}
                    strokeLinecap="round"
                    fill="transparent"
                    className="transition-all duration-700 ease-out"
                  />
                </svg>
                <div className="absolute flex flex-col items-center justify-center">
                  <span className="text-3xl font-black text-white font-mono">
                    {prediction.riskScore}%
                  </span>
                  <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                    Risk Score
                  </span>
                </div>
              </div>

              {/* Status Badge */}
              <div>
                <span
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border ${
                    prediction.verdict === 'Critical Threat'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : prediction.verdict === 'Suspicious'
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                      : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                  }`}
                >
                  {prediction.verdict === 'Critical Threat' ? (
                    <ShieldAlert className="w-3.5 h-3.5" />
                  ) : prediction.verdict === 'Suspicious' ? (
                    <AlertTriangle className="w-3.5 h-3.5" />
                  ) : (
                    <ShieldCheck className="w-3.5 h-3.5" />
                  )}
                  {prediction.verdict}
                </span>
              </div>

              {/* Natural Language Summary */}
              <p className="text-xs text-slate-300 leading-relaxed pt-1">
                {prediction.naturalSummary}
              </p>

              {/* Suggested Immediate Action */}
              <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 text-left text-xs">
                <span className="text-slate-400 font-semibold block text-[10px] uppercase tracking-wider mb-0.5">
                  Recommended Action:
                </span>
                <p className="text-slate-200">{prediction.suggestedAction}</p>
              </div>
            </div>
          </div>

          {/* Explainability Breakdown (Why did the model predict this?) */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-blue-400" />
                Why the Model Decided This (Explainable AI)
              </h4>
            </div>

            <p className="text-[11px] text-slate-400">
              Relative feature impact pushing the risk score up or down:
            </p>

            <div className="space-y-2 pt-1">
              {prediction.featureContributions.slice(0, 4).map((contrib) => (
                <div
                  key={contrib.feature}
                  className="bg-slate-950 p-2.5 rounded-lg border border-slate-800 text-xs space-y-1"
                >
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-slate-200">{contrib.label}</span>
                    <span
                      className={`font-mono font-bold text-[11px] ${
                        contrib.contributionScore > 0 ? 'text-rose-400' : 'text-emerald-400'
                      }`}
                    >
                      {contrib.contributionScore > 0
                        ? `+${contrib.contributionScore}% Threat Impact`
                        : `${contrib.contributionScore}% Threat Impact`}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">{contrib.explanation}</p>
                </div>
              ))}
            </div>
          </div>

          {/* AI Security Copilot Debrief Button */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-300" />
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Plain-English AI Debrief
                </h4>
              </div>
            </div>

            <p className="text-xs text-slate-400">
              Need a personalized explanation written for non-technical employees? Click below to generate an AI summary.
            </p>

            <button
              onClick={handleAskAiDebrief}
              disabled={loadingAi}
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 shadow-sm transition"
            >
              {loadingAi ? (
                <span>Generating Plain-English Debrief...</span>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>Generate Plain-English Debrief</span>
                </>
              )}
            </button>

            {aiDebrief && (
              <div className="mt-3 p-3.5 bg-blue-950/30 border border-blue-800/40 rounded-xl text-xs text-blue-200 leading-relaxed whitespace-pre-line">
                {aiDebrief}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
