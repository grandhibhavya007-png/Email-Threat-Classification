import React from 'react';
import { ShieldCheck, BookOpen, Sparkles, RefreshCw, FileText } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenGlossary: () => void;
  onOpenAiSummary: () => void;
  onResetData: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenGlossary,
  onOpenAiSummary,
  onResetData,
}) => {
  const navTabs = [
    { id: 'eda', label: '1. Data & EDA Explorer', icon: '📊' },
    { id: 'training', label: '2. Train & Compare Models', icon: '🤖' },
    { id: 'evaluation', label: '3. Metrics & Confusion Matrix', icon: '🎯' },
    { id: 'scanner', label: '4. Live Threat Sandbox', icon: '🛡️' },
    { id: 'capstone', label: '5. Capstone Paper & Presentation', icon: '📝' },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-lg">
      {/* Top Banner with Capstone Context */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-cyan-600 px-4 py-1.5 text-xs text-blue-100 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="bg-white/20 font-semibold px-2 py-0.5 rounded text-white tracking-wide uppercase text-[10px]">
            Capstone Problem 05
          </span>
          <span>Learn Depth Academy LLP • Track 1 Final Capstone: Email Threat Classification</span>
        </div>
        <div className="flex items-center gap-3 text-[11px]">
          <span className="hidden sm:inline text-blue-200">
            Foundational ML: Zero-Cost • Non-Technical Simplification
          </span>
          <span className="bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 px-2 py-0.5 rounded font-mono">
            Binary Classification
          </span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-500 to-cyan-400 flex items-center justify-center shadow-md shadow-blue-500/30">
            <ShieldCheck className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold tracking-tight text-white">DataSight ML</h1>
              <span className="text-[11px] bg-blue-500/20 border border-blue-400/30 text-blue-300 px-2 py-0.5 rounded-full font-medium">
                Plain English AI
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Demystifying complex cybersecurity email datasets with intuitive visuals & human summaries
            </p>
          </div>
        </div>

        {/* Global Action Tools */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenGlossary}
            className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            title="Non-technical terms glossary"
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400" />
            <span>Plain Glossary</span>
          </button>

          <button
            onClick={onOpenAiSummary}
            className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-sm shadow-blue-600/30 transition"
            title="Generate executive narrative"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Executive Brief</span>
          </button>

          <button
            onClick={onResetData}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-slate-200 border border-slate-700 transition"
            title="Reset dataset to default"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 border-t border-slate-800/80 flex overflow-x-auto no-scrollbar">
        {navTabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'border-blue-500 text-blue-400 bg-blue-500/10'
                : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <span>{tab.icon}</span>
            <span>{tab.label}</span>
          </button>
        ))}
      </div>
    </header>
  );
};
