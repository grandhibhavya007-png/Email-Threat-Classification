import React, { useState } from 'react';
import { EvaluationMetrics } from '../types/dataset';
import { translateMetricsToPlainEnglish } from '../utils/plainEnglishSummarizer';
import {
  Target,
  CheckCircle,
  AlertOctagon,
  ShieldAlert,
  Sliders,
  HelpCircle,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';

interface ModelEvaluationTabProps {
  metrics: EvaluationMetrics;
  modelName: string;
  threshold: number;
  setThreshold: (t: number) => void;
}

export const ModelEvaluationTab: React.FC<ModelEvaluationTabProps> = ({
  metrics,
  modelName,
  threshold,
  setThreshold,
}) => {
  const [activeMetricDetail, setActiveMetricDetail] = useState<string>('recall');
  const [showHelper, setShowHelper] = useState(true);

  const plainMetrics = translateMetricsToPlainEnglish(metrics);
  const { tp, fp, tn, fn } = metrics.confusionMatrix;
  const totalTest = tp + fp + tn + fn;

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-900/40 via-indigo-950/40 to-slate-900 border border-blue-800/40 rounded-2xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-blue-400 font-semibold text-sm mb-1">
              <Target className="w-4 h-4" />
              <span>Step 04 of 05 • Metric Interpretation & Risk Translation</span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Translating Math into Real-World Cybersecurity Consequences
            </h2>
            <p className="text-sm text-slate-300 max-w-3xl mt-1">
              The Capstone rubric requires students to <em>interpret</em> metrics rather than merely report raw numbers. Below, we explain what false alarms and missed attacks mean for an everyday company.
            </p>
          </div>
          <button
            onClick={() => setShowHelper(!showHelper)}
            className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 transition shrink-0"
          >
            <HelpCircle className="w-4 h-4" />
            <span>{showHelper ? 'Hide Guide' : 'Non-Technical Guide'}</span>
          </button>
        </div>

        {showHelper && (
          <div className="mt-4 pt-4 border-t border-slate-800 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-300">
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
              <span className="font-semibold text-rose-300 block mb-1">
                ⚠️ False Negative (The Danger Zone)
              </span>
              A real phishing attack that slipped past the filter into someone&apos;s inbox. The user might click it and cause a ransomware outbreak or data breach.
            </div>
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
              <span className="font-semibold text-amber-300 block mb-1">
                🔔 False Positive (The Annoyance Zone)
              </span>
              A harmless routine email sent to quarantine by mistake. Frustrating for employees, but does not compromise network security.
            </div>
          </div>
        )}
      </div>

      {/* 5 Key Metric Cards with Plain-English Translation */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        {Object.entries(plainMetrics).map(([key, data]) => {
          const isSelected = activeMetricDetail === key;
          return (
            <button
              key={key}
              onClick={() => setActiveMetricDetail(key)}
              className={`text-left p-4 rounded-xl border transition-all ${
                isSelected
                  ? 'bg-blue-900/30 border-blue-500 shadow-md ring-1 ring-blue-500/50'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                {data.metric.split(' ')[0]}
              </div>
              <div className="text-2xl font-black text-white mt-1">
                {data.scoreDisplay}
              </div>
              <div className="text-[11px] text-slate-400 mt-1 line-clamp-2">
                {data.nonTechnicalTranslation}
              </div>
              <div className="mt-2 text-[10px] text-blue-400 font-semibold flex items-center gap-1">
                <span>{isSelected ? 'Viewing Interpretation ↓' : 'Click to interpret →'}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Deep Metric Interpretation Box */}
      {activeMetricDetail && plainMetrics[activeMetricDetail] && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              Non-Technical Interpretation for {plainMetrics[activeMetricDetail].metric}:
            </h3>
            <span className="text-xs font-mono font-bold text-blue-400">
              Score: {plainMetrics[activeMetricDetail].scoreDisplay}
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1 text-xs">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider block mb-1">
                Plain English Meaning
              </span>
              <p className="text-slate-200">
                {plainMetrics[activeMetricDetail].nonTechnicalTranslation}
              </p>
            </div>
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <span className="text-slate-400 uppercase font-semibold text-[10px] tracking-wider block mb-1">
                Business & Security Impact
              </span>
              <p className="text-slate-200">
                {plainMetrics[activeMetricDetail].realWorldRiskStory}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Interactive Confusion Matrix & Decision Threshold */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: The Confusion Matrix Translator (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                The Confusion Matrix Explained for Non-Technical Users
              </h3>
              <p className="text-xs text-slate-400">
                Evaluated on {totalTest} unseen test emails under {modelName}
              </p>
            </div>
            <span className="text-xs bg-slate-800 text-slate-300 px-2.5 py-1 rounded-lg border border-slate-700 font-mono">
              Threshold: {(threshold * 100).toFixed(0)}%
            </span>
          </div>

          {/* Visual Matrix Grid */}
          <div className="grid grid-cols-2 gap-3 pt-2">
            {/* True Negative: Safe Allowed */}
            <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-xl p-4 relative overflow-hidden">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5" />
                  True Negative (Safe Allowed)
                </span>
                <span className="text-xl font-bold font-mono text-emerald-300">{tn}</span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1">
                Normal workplace emails correctly delivered to inboxes without delay.
              </p>
              <div className="mt-2 text-[10px] text-emerald-400 font-medium">
                Business Impact: Seamless productivity.
              </div>
            </div>

            {/* False Positive: Safe Quarantined */}
            <div className="bg-amber-950/30 border border-amber-500/30 rounded-xl p-4 relative overflow-hidden">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                  <AlertOctagon className="w-3.5 h-3.5" />
                  False Positive (False Alarm)
                </span>
                <span className="text-xl font-bold font-mono text-amber-300">{fp}</span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1">
                Harmless everyday emails mistakenly flagged as phishing and quarantined.
              </p>
              <div className="mt-2 text-[10px] text-amber-400 font-medium">
                Business Impact: Mild inconvenience / employee irritation.
              </div>
            </div>

            {/* False Negative: Attack Slipped In (Danger!) */}
            <div className="bg-rose-950/40 border border-rose-500/40 rounded-xl p-4 relative overflow-hidden ring-1 ring-rose-500/30">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-rose-400 flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5" />
                  False Negative (Attack Missed!)
                </span>
                <span className="text-xl font-bold font-mono text-rose-400">{fn}</span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1">
                Real cyber attacks that bypassed detection and reached employee inboxes!
              </p>
              <div className="mt-2 text-[10px] text-rose-400 font-bold uppercase">
                🚨 CRITICAL: Highest Cybersecurity Hazard!
              </div>
            </div>

            {/* True Positive: Threat Neutralized */}
            <div className="bg-blue-950/30 border border-blue-500/30 rounded-xl p-4 relative overflow-hidden">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-blue-400 flex items-center gap-1.5">
                  <CheckCircle className="w-3.5 h-3.5" />
                  True Positive (Threat Caught)
                </span>
                <span className="text-xl font-bold font-mono text-blue-300">{tp}</span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1">
                Malicious attacks successfully intercepted before user could interact.
              </p>
              <div className="mt-2 text-[10px] text-blue-400 font-medium">
                Business Impact: Organization protected from breach.
              </div>
            </div>
          </div>

          {/* Non-Technical Summary of Matrix */}
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs text-slate-300">
            <strong>Key Capstone Conclusion:</strong> Out of {tp + fn} real attack attempts in the test set, the system stopped <strong className="text-emerald-400">{tp}</strong> ({((tp / (tp + fn || 1)) * 100).toFixed(1)}%). Only <strong className="text-rose-400">{fn}</strong> slipped past. Meanwhile, out of {tn + fp} safe emails, only <strong className="text-amber-400">{fp}</strong> suffered false alarms.
          </div>
        </div>

        {/* Right: Threshold Slider & Sensitivity Tuning (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Sensitivity Threshold Tuning
            </h3>
          </div>

          <p className="text-xs text-slate-400">
            How strict should our email gatekeeper be? Move the slider to see how raising or lowering the threshold impacts safety vs convenience:
          </p>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-300 font-semibold">Classification Cutoff:</span>
              <span className="font-mono text-base font-bold text-blue-400">
                {(threshold * 100).toFixed(0)}%
              </span>
            </div>

            <input
              type="range"
              min="0.1"
              max="0.9"
              step="0.05"
              value={threshold}
              onChange={(e) => setThreshold(parseFloat(e.target.value))}
              className="w-full accent-blue-500"
            />

            <div className="flex justify-between text-[11px] text-slate-500">
              <span>0.1 (High Alert / Catch Everything)</span>
              <span>0.9 (Permissive / Few Alarms)</span>
            </div>

            <div className="pt-2 border-t border-slate-800 space-y-2 text-xs">
              {threshold <= 0.35 ? (
                <div className="p-2.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30 text-emerald-200">
                  <strong className="block text-white font-semibold">High Security Mode:</strong>
                  The system flags anything remotely suspicious. Missed attacks drop near zero, but some innocent emails may get sent to spam.
                </div>
              ) : threshold >= 0.65 ? (
                <div className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-500/30 text-amber-200">
                  <strong className="block text-white font-semibold">High Convenience Mode:</strong>
                  Virtually zero false alarms for staff. However, crafty attackers might slip through the gate.
                </div>
              ) : (
                <div className="p-2.5 rounded-lg bg-blue-950/40 border border-blue-500/30 text-blue-200">
                  <strong className="block text-white font-semibold">Balanced Default Mode:</strong>
                  Optimized trade-off between employee productivity and cyber threat defense.
                </div>
              )}
            </div>
          </div>

          {/* ROC Curve Mini Visualization */}
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-blue-400" />
                ROC Curve (Receiver Operating Characteristic)
              </span>
              <span className="font-mono text-amber-300 font-bold">
                AUC: {metrics.rocAuc.toFixed(3)}
              </span>
            </div>

            {/* SVG ROC Curve */}
            <div className="h-32 w-full flex items-center justify-center pt-2">
              <svg viewBox="0 0 100 100" className="w-full h-full max-w-[200px] overflow-visible">
                {/* Background Grid */}
                <line x1="0" y1="100" x2="100" y2="100" stroke="#334155" strokeWidth="1" />
                <line x1="0" y1="0" x2="0" y2="100" stroke="#334155" strokeWidth="1" />
                {/* Diagonal Chance Line */}
                <line
                  x1="0"
                  y1="100"
                  x2="100"
                  y2="0"
                  stroke="#475569"
                  strokeWidth="1"
                  strokeDasharray="3 3"
                />
                {/* Model ROC Curve Path */}
                <path
                  d="M 0 100 Q 5 20, 25 8 T 100 0"
                  fill="none"
                  stroke="#3b82f6"
                  strokeWidth="2.5"
                />
                {/* Current Threshold Point */}
                <circle
                  cx={Math.max(5, Math.min(95, Math.round(fp / (tn + fp || 1) * 100)))}
                  cy={Math.max(5, Math.min(95, 100 - Math.round(tp / (tp + fn || 1) * 100)))}
                  r="4"
                  fill="#f59e0b"
                  stroke="#ffffff"
                  strokeWidth="1.5"
                />
              </svg>
            </div>

            <div className="flex justify-between text-[10px] text-slate-400 pt-1">
              <span>0% False Alarms</span>
              <span className="text-amber-300">● Current Operating Point</span>
              <span>100% Catch Rate</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
