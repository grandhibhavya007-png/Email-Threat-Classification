import React, { useState, useMemo } from 'react';
import { EmailRecord, FeatureKey } from '../types/dataset';
import { FEATURE_METADATA } from '../data/emailDataset';
import {
  CheckCircle2,
  AlertTriangle,
  Info,
  Search,
  Filter,
  Download,
  Upload,
  BarChart2,
  HelpCircle,
  FileCheck,
} from 'lucide-react';

interface DataExplorationTabProps {
  dataset: EmailRecord[];
  onUploadCsv: (newRecords: EmailRecord[]) => void;
}

export const DataExplorationTab: React.FC<DataExplorationTabProps> = ({
  dataset,
  onUploadCsv,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterClass, setFilterClass] = useState<'all' | 'safe' | 'threat'>('all');
  const [selectedFeature, setSelectedFeature] = useState<FeatureKey>('urgency_keywords');
  const [showExplanation, setShowExplanation] = useState(true);

  // 1. Data Quality Health Stats
  const totalCount = dataset.length;
  const threatCount = dataset.filter((d) => d.threat_class === 1).length;
  const safeCount = totalCount - threatCount;
  const threatPercent = ((threatCount / totalCount) * 100).toFixed(1);
  const safePercent = ((safeCount / totalCount) * 100).toFixed(1);

  // Check missing values and duplicates
  const missingValuesCount = useMemo(() => {
    let missing = 0;
    dataset.forEach((row) => {
      Object.values(row).forEach((v) => {
        if (v === undefined || v === null || Number.isNaN(v)) missing++;
      });
    });
    return missing;
  }, [dataset]);

  const duplicateCount = useMemo(() => {
    const ids = new Set<string>();
    let dupes = 0;
    dataset.forEach((row) => {
      if (ids.has(row.id)) dupes++;
      else ids.add(row.id);
    });
    return dupes;
  }, [dataset]);

  // 2. Feature Distribution Calculations (Safe vs Threat)
  const distributionData = useMemo(() => {
    const meta = FEATURE_METADATA[selectedFeature];
    const safeItems = dataset.filter((d) => d.threat_class === 0);
    const threatItems = dataset.filter((d) => d.threat_class === 1);

    if (meta.type === 'binary') {
      const safeFlagged = safeItems.filter((d) => d[selectedFeature] === 1).length;
      const threatFlagged = threatItems.filter((d) => d[selectedFeature] === 1).length;

      return {
        type: 'binary' as const,
        safeRatio: (safeFlagged / (safeItems.length || 1)) * 100,
        threatRatio: (threatFlagged / (threatItems.length || 1)) * 100,
        safeCount: safeFlagged,
        threatCount: threatFlagged,
      };
    } else {
      // Group into numeric buckets
      const maxVal = Math.max(...dataset.map((d) => d[selectedFeature])) || 10;
      const numBuckets = 5;
      const bucketSize = Math.max(1, Math.ceil(maxVal / numBuckets));

      const buckets = Array.from({ length: numBuckets }, (_, i) => {
        const min = i * bucketSize;
        const max = (i + 1) * bucketSize;
        const label = i === numBuckets - 1 ? `${min}+` : `${min}-${max}`;

        const safeInBucket = safeItems.filter((d) => {
          const val = d[selectedFeature];
          return i === numBuckets - 1 ? val >= min : val >= min && val < max;
        }).length;

        const threatInBucket = threatItems.filter((d) => {
          const val = d[selectedFeature];
          return i === numBuckets - 1 ? val >= min : val >= min && val < max;
        }).length;

        return {
          label,
          safeCount: safeInBucket,
          threatCount: threatInBucket,
          safePct: (safeInBucket / (safeItems.length || 1)) * 100,
          threatPct: (threatInBucket / (threatItems.length || 1)) * 100,
        };
      });

      return {
        type: 'numeric' as const,
        buckets,
        avgSafe: (
          safeItems.reduce((acc, d) => acc + d[selectedFeature], 0) / (safeItems.length || 1)
        ).toFixed(1),
        avgThreat: (
          threatItems.reduce((acc, d) => acc + d[selectedFeature], 0) / (threatItems.length || 1)
        ).toFixed(1),
      };
    }
  }, [dataset, selectedFeature]);

  // 3. Filtered Table Rows
  const filteredRows = useMemo(() => {
    return dataset
      .filter((row) => {
        if (filterClass === 'safe' && row.threat_class !== 0) return false;
        if (filterClass === 'threat' && row.threat_class !== 1) return false;
        if (searchQuery.trim() === '') return true;
        const q = searchQuery.toLowerCase();
        return (
          row.subject.toLowerCase().includes(q) ||
          row.sender.toLowerCase().includes(q) ||
          row.id.toLowerCase().includes(q)
        );
      })
      .slice(0, 100); // display top 100 for fast rendering
  }, [dataset, filterClass, searchQuery]);

  // CSV Export handler
  const handleExportCsv = () => {
    const headers = [
      'id',
      'subject',
      'sender',
      'message_length',
      'url_count',
      'attachment_count',
      'urgency_keywords',
      'suspicious_domain',
      'display_name_mismatch',
      'has_executable_attachment',
      'threat_class',
    ];
    const rows = dataset.map((d) =>
      [
        d.id,
        `"${d.subject.replace(/"/g, '""')}"`,
        `"${d.sender}"`,
        d.message_length,
        d.url_count,
        d.attachment_count,
        d.urgency_keywords,
        d.suspicious_domain,
        d.display_name_mismatch,
        d.has_executable_attachment,
        d.threat_class,
      ].join(',')
    );
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'email_threat_capstone_dataset.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // CSV Import handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').filter((l) => l.trim() !== '');
        if (lines.length < 2) return;

        const headers = lines[0].split(',').map((h) => h.trim().replace(/^"|"$/g, ''));
        const newRecords: EmailRecord[] = [];

        for (let i = 1; i < lines.length; i++) {
          const cols = lines[i].split(',').map((c) => c.trim().replace(/^"|"$/g, ''));
          if (cols.length >= 7) {
            newRecords.push({
              id: cols[0] || `custom-${i}`,
              subject: cols[1] || 'Custom Email Observation',
              sender: cols[2] || 'external@sender.com',
              recipient: 'employee@company.org',
              message_length: parseInt(cols[3] || '500', 10) || 500,
              url_count: parseInt(cols[4] || '1', 10) || 0,
              attachment_count: parseInt(cols[5] || '0', 10) || 0,
              urgency_keywords: parseInt(cols[6] || '0', 10) || 0,
              suspicious_domain: parseInt(cols[7] || '0', 10) > 0 ? 1 : 0,
              display_name_mismatch: parseInt(cols[8] || '0', 10) > 0 ? 1 : 0,
              has_executable_attachment: parseInt(cols[9] || '0', 10) > 0 ? 1 : 0,
              threat_class: parseInt(cols[10] || '0', 10) > 0 ? 1 : 0,
            });
          }
        }

        if (newRecords.length > 0) {
          onUploadCsv(newRecords);
        }
      } catch (err) {
        console.error('Failed to parse uploaded CSV:', err);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      {/* Non-Technical Simplification Banner */}
      <div className="bg-gradient-to-r from-blue-900/40 via-indigo-950/40 to-slate-900 border border-blue-800/40 rounded-2xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-blue-400 font-semibold text-sm mb-1">
              <Info className="w-4 h-4" />
              <span>Step 02 of 05 • Exploratory Data Analysis (EDA)</span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Understanding the Raw Data Before Machine Learning
            </h2>
            <p className="text-sm text-slate-300 max-w-3xl mt-1">
              In simple terms: An AI model is only as smart as the data you feed it. Before training, we verify data quality, ensure there are no missing records, check class balance, and discover which email traits separate honest emails from cyber attacks.
            </p>
          </div>
          <button
            onClick={() => setShowExplanation(!showExplanation)}
            className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-lg bg-blue-600/20 text-blue-300 border border-blue-500/30 hover:bg-blue-600/30 transition shrink-0"
          >
            <HelpCircle className="w-4 h-4" />
            <span>{showExplanation ? 'Hide Guide' : 'Non-Technical Guide'}</span>
          </button>
        </div>

        {showExplanation && (
          <div className="mt-4 pt-4 border-t border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs text-slate-300">
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
              <span className="font-semibold text-white block mb-1">1. Zero Missing Values</span>
              Every observation has complete numbers. No gaps or broken rows that would confuse our classifier.
            </div>
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
              <span className="font-semibold text-white block mb-1">2. Balanced Threat Classes</span>
              Roughly 55% routine vs 45% malicious. The model won't develop an accidental bias toward one class.
            </div>
            <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700/50">
              <span className="font-semibold text-white block mb-1">3. Measurable Signals</span>
              Instead of deep-learning text embeddings, we focus on observable metrics: URLs, panic words, and sender domain lookalikes.
            </div>
          </div>
        )}
      </div>

      {/* 4 Health Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Observations */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase font-semibold tracking-wider">Total Emails Analyzed</span>
            <FileCheck className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-white">{totalCount.toLocaleString()}</div>
          <p className="text-xs text-slate-400 mt-1">Realistic communications sample</p>
        </div>

        {/* Data Quality & Missing Values */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase font-semibold tracking-wider">Data Quality & Cleanliness</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400">100% Clean</div>
          <p className="text-xs text-slate-400 mt-1">
            {missingValuesCount} missing fields • {duplicateCount} duplicates
          </p>
        </div>

        {/* Routine Safe Emails */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase font-semibold tracking-wider">Routine / Safe Emails</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          </div>
          <div className="text-2xl font-bold text-white">
            {safeCount} <span className="text-sm font-normal text-slate-400">({safePercent}%)</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">Normal daily workplace messages</p>
        </div>

        {/* Malicious Threats */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-sm">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-xs uppercase font-semibold tracking-wider">Potentially Threatening</span>
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
          </div>
          <div className="text-2xl font-bold text-rose-400">
            {threatCount} <span className="text-sm font-normal text-slate-400">({threatPercent}%)</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">Phishing, credential traps, malware</p>
        </div>
      </div>

      {/* Class Balance Visual Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center justify-between text-xs text-slate-300 font-semibold mb-2">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <span className="w-3 h-3 rounded-full bg-emerald-500 inline-block"></span>
            Routine Emails: {safeCount} ({safePercent}%)
          </span>
          <span className="flex items-center gap-1.5 text-rose-400">
            Malicious Threats: {threatCount} ({threatPercent}%)
            <span className="w-3 h-3 rounded-full bg-rose-500 inline-block"></span>
          </span>
        </div>

        {/* Visual Dual Progress Bar */}
        <div className="w-full h-4 bg-slate-800 rounded-full overflow-hidden flex border border-slate-700">
          <div
            style={{ width: `${safePercent}%` }}
            className="bg-emerald-500 h-full transition-all duration-500 flex items-center justify-center text-[10px] text-emerald-950 font-bold"
          >
            Safe
          </div>
          <div
            style={{ width: `${threatPercent}%` }}
            className="bg-rose-500 h-full transition-all duration-500 flex items-center justify-center text-[10px] text-rose-950 font-bold"
          >
            Threat
          </div>
        </div>

        <p className="text-xs text-slate-400 mt-2.5">
          <strong className="text-slate-200">Non-Technical Meaning:</strong> Unlike imbalanced real-world logs (where 99% of emails are safe, which encourages algorithms to cheat by guessing "Safe" every time), this calibrated capstone dataset gives the model equal opportunity to learn the distinct anatomy of an attack.
        </p>
      </div>

      {/* Interactive Feature Distribution & Visual Comparison */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <BarChart2 className="w-5 h-5 text-blue-400" />
              <h3 className="text-lg font-bold text-white">
                Feature Comparison: Safe vs Malicious Emails
              </h3>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Select a characteristic below to see how cyber attacks differ from regular office emails
            </p>
          </div>

          {/* Feature Selector Dropdown */}
          <div className="flex items-center gap-2 w-full md:w-auto">
            <span className="text-xs text-slate-400 shrink-0 font-medium">Characteristic:</span>
            <select
              value={selectedFeature}
              onChange={(e) => setSelectedFeature(e.target.value as FeatureKey)}
              className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-blue-500 w-full md:w-auto"
            >
              {Object.values(FEATURE_METADATA).map((meta) => (
                <option key={meta.key} value={meta.key}>
                  {meta.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Feature Context Banner */}
        <div className="bg-slate-800/60 rounded-xl p-3 border border-slate-700/60 mb-6 flex items-start gap-3 text-xs">
          <div className="p-1.5 rounded-lg bg-blue-500/20 text-blue-400 shrink-0 mt-0.5">
            <Info className="w-4 h-4" />
          </div>
          <div>
            <div className="font-semibold text-slate-200">
              {FEATURE_METADATA[selectedFeature].label}
            </div>
            <p className="text-slate-400 mt-0.5">
              {FEATURE_METADATA[selectedFeature].nonTechnicalHelp}
            </p>
          </div>
        </div>

        {/* Visual Charts */}
        {distributionData.type === 'binary' ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Safe Emails Presence */}
              <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-emerald-400 font-semibold flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                    Routine / Safe Emails
                  </span>
                  <span className="text-white font-mono font-bold">
                    {distributionData.safeRatio.toFixed(1)}% Present
                  </span>
                </div>
                <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${distributionData.safeRatio}%` }}
                    className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                  ></div>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  {distributionData.safeCount} out of {safeCount} routine emails exhibited this flag.
                </p>
              </div>

              {/* Threat Emails Presence */}
              <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-xl">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-rose-400 font-semibold flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                    Malicious Threat Emails
                  </span>
                  <span className="text-white font-mono font-bold">
                    {distributionData.threatRatio.toFixed(1)}% Present
                  </span>
                </div>
                <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${distributionData.threatRatio}%` }}
                    className="bg-rose-500 h-full rounded-full transition-all duration-500"
                  ></div>
                </div>
                <p className="text-[11px] text-slate-400 mt-2">
                  {distributionData.threatCount} out of {threatCount} malicious emails exhibited this flag.
                </p>
              </div>
            </div>

            {/* Non technical key takeaway */}
            <div className="p-3.5 bg-blue-950/30 border border-blue-800/40 rounded-xl text-xs text-blue-200">
              <strong className="text-white">Plain-English Takeaway:</strong>{' '}
              {distributionData.threatRatio > 50
                ? `This indicator is a decisive weapon for the model! While safe emails almost never exhibit this trait (${distributionData.safeRatio.toFixed(
                    1
                  )}%), over ${distributionData.threatRatio.toFixed(
                    0
                  )}% of cyber attacks rely on it.`
                : `This trait appears infrequently, but when present, provides valuable corroborating evidence for the classifier.`}
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Average summary pill */}
            <div className="flex flex-wrap items-center gap-4 text-xs bg-slate-950/40 p-3 rounded-xl border border-slate-800">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                <span className="text-slate-300">Average for Safe Emails:</span>
                <span className="font-bold font-mono text-emerald-400 text-sm">
                  {distributionData.avgSafe} {FEATURE_METADATA[selectedFeature].unit}
                </span>
              </div>
              <div className="h-4 w-px bg-slate-700 hidden sm:block"></div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-rose-500"></span>
                <span className="text-slate-300">Average for Threat Emails:</span>
                <span className="font-bold font-mono text-rose-400 text-sm">
                  {distributionData.avgThreat} {FEATURE_METADATA[selectedFeature].unit}
                </span>
              </div>
            </div>

            {/* Bucketed comparison bar chart */}
            <div className="space-y-3 pt-2">
              {distributionData.buckets?.map((bucket, idx) => (
                <div key={idx} className="space-y-1">
                  <div className="flex items-center justify-between text-xs text-slate-300 font-medium">
                    <span className="font-mono text-slate-200 w-24">
                      {bucket.label} {FEATURE_METADATA[selectedFeature].unit}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Safe: {bucket.safePct.toFixed(0)}% • Threat: {bucket.threatPct.toFixed(0)}%
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    {/* Safe bar */}
                    <div className="w-full bg-slate-950 rounded-lg h-5 overflow-hidden flex items-center px-2">
                      <div
                        style={{ width: `${bucket.safePct}%` }}
                        className="bg-emerald-500/80 hover:bg-emerald-400 h-3 rounded transition-all duration-300"
                        title={`${bucket.safeCount} safe emails`}
                      ></div>
                    </div>
                    {/* Threat bar */}
                    <div className="w-full bg-slate-950 rounded-lg h-5 overflow-hidden flex items-center px-2">
                      <div
                        style={{ width: `${bucket.threatPct}%` }}
                        className="bg-rose-500/80 hover:bg-rose-400 h-3 rounded transition-all duration-300"
                        title={`${bucket.threatCount} threat emails`}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Bottom Insight Box */}
            <div className="p-3.5 bg-blue-950/30 border border-blue-800/40 rounded-xl text-xs text-blue-200">
              <strong className="text-white">Plain-English Takeaway:</strong>{' '}
              {parseFloat(distributionData.avgThreat || '0') >
              parseFloat(distributionData.avgSafe || '0')
                ? `Malicious emails contain significantly higher ${FEATURE_METADATA[
                    selectedFeature
                  ].label.toLowerCase()} (average ${distributionData.avgThreat}) than normal workplace emails (${
                    distributionData.avgSafe
                  }). The algorithm uses this clear gap to draw separating decision boundaries.`
                : `Safe communications and threat emails share overlapping distributions on this metric, meaning no single feature is enough by itself—the machine learning model must synthesize multiple clues simultaneously.`}
            </div>
          </div>
        )}
      </div>

      {/* Raw Data Inspector Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white">
              Dataset Records Explorer & Verifier
            </h3>
            <p className="text-xs text-slate-400">
              Inspect individual sample records, filter categories, or download CSV for offline analysis
            </p>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              title="Download full dataset as CSV"
            >
              <Download className="w-3.5 h-3.5 text-blue-400" />
              <span>Export CSV</span>
            </button>

            <label className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition cursor-pointer">
              <Upload className="w-3.5 h-3.5 text-cyan-400" />
              <span>Import CSV</span>
              <input
                type="file"
                accept=".csv"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative w-full sm:flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by subject, sender, or ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <Filter className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                onClick={() => setFilterClass('all')}
                className={`px-2.5 py-1 rounded font-medium transition ${
                  filterClass === 'all'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                All ({totalCount})
              </button>
              <button
                onClick={() => setFilterClass('safe')}
                className={`px-2.5 py-1 rounded font-medium transition ${
                  filterClass === 'safe'
                    ? 'bg-emerald-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Safe ({safeCount})
              </button>
              <button
                onClick={() => setFilterClass('threat')}
                className={`px-2.5 py-1 rounded font-medium transition ${
                  filterClass === 'threat'
                    ? 'bg-rose-600 text-white'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Threats ({threatCount})
              </button>
            </div>
          </div>
        </div>

        {/* Table View */}
        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Subject & Sender</th>
                <th className="py-2.5 px-3 text-center">Length</th>
                <th className="py-2.5 px-3 text-center">URLs</th>
                <th className="py-2.5 px-3 text-center">Attach.</th>
                <th className="py-2.5 px-3 text-center">Urgency</th>
                <th className="py-2.5 px-3 text-center">Spoofed Domain</th>
                <th className="py-2.5 px-3 text-center">Dangerous Ext</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 bg-slate-900/50">
              {filteredRows.map((row) => (
                <tr key={row.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 whitespace-nowrap">
                    {row.threat_class === 1 ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                        <AlertTriangle className="w-3 h-3 text-rose-400" />
                        Threat
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        Routine
                      </span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 max-w-xs">
                    <div className="font-medium text-white truncate">{row.subject}</div>
                    <div className="text-[11px] text-slate-400 truncate">{row.sender}</div>
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono text-slate-300">
                    {row.message_length}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono text-slate-300">
                    {row.url_count}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono text-slate-300">
                    {row.attachment_count}
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono">
                    <span
                      className={
                        row.urgency_keywords > 2
                          ? 'text-rose-400 font-bold'
                          : row.urgency_keywords > 0
                          ? 'text-amber-400'
                          : 'text-slate-400'
                      }
                    >
                      {row.urgency_keywords}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {row.suspicious_domain ? (
                      <span className="text-rose-400 font-semibold">Yes</span>
                    ) : (
                      <span className="text-slate-500">No</span>
                    )}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    {row.has_executable_attachment ? (
                      <span className="text-rose-400 font-bold">.exe / .zip</span>
                    ) : (
                      <span className="text-slate-500">None</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="text-[11px] text-slate-500 flex justify-between items-center">
          <span>Showing {filteredRows.length} of {dataset.length} total records</span>
          <span>Capstone Milestone 02: Data Quality & EDA Complete</span>
        </div>
      </div>
    </div>
  );
};
