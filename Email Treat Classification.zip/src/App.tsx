/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { EMAIL_DATASET } from './data/emailDataset';
import { EmailRecord, ModelAlgorithm } from './types/dataset';
import {
  fitScalers,
  trainTestSplit,
  trainLogisticRegression,
  trainDecisionTree,
  trainKNN,
  evaluatePredictions,
  compareFoundationalModels,
  transformFeatures,
} from './utils/mlEngine';
import { Header } from './components/Header';
import { DataExplorationTab } from './components/DataExplorationTab';
import { ModelTrainingTab } from './components/ModelTrainingTab';
import { ModelEvaluationTab } from './components/ModelEvaluationTab';
import { LiveThreatScannerTab } from './components/LiveThreatScannerTab';
import { CapstoneReportTab } from './components/CapstoneReportTab';
import { NonTechnicalGlossaryModal } from './components/NonTechnicalGlossaryModal';
import { AiExecutiveSummaryModal } from './components/AiExecutiveSummaryModal';

export default function App() {
  const [dataset, setDataset] = useState<EmailRecord[]>(EMAIL_DATASET);
  const [trainRatio, setTrainRatio] = useState<number>(0.75);
  const [activeTab, setActiveTab] = useState<string>('eda');
  const [activeModelType, setActiveModelType] = useState<ModelAlgorithm>('logistic_regression');
  const [threshold, setThreshold] = useState<number>(0.5);

  // Hyperparameters
  const [hyperparams, setHyperparams] = useState<{
    lrEpochs: number;
    treeDepth: number;
    knnK: number;
  }>({
    lrEpochs: 80,
    treeDepth: 4,
    knnK: 5,
  });

  // Modals
  const [isGlossaryOpen, setIsGlossaryOpen] = useState(false);
  const [isAiSummaryOpen, setIsAiSummaryOpen] = useState(false);

  // 1. Train / Test Split & Normalization Scalers
  const { train: trainData, test: testData } = useMemo(() => {
    return trainTestSplit(dataset, trainRatio);
  }, [dataset, trainRatio]);

  const scalers = useMemo(() => {
    return fitScalers(trainData);
  }, [trainData]);

  // 2. Train Foundational Models
  const logisticModel = useMemo(() => {
    return trainLogisticRegression(trainData, scalers, hyperparams.lrEpochs);
  }, [trainData, scalers, hyperparams.lrEpochs]);

  const decisionTreeModel = useMemo(() => {
    return trainDecisionTree(trainData, hyperparams.treeDepth);
  }, [trainData, hyperparams.treeDepth]);

  const knnModel = useMemo(() => {
    return trainKNN(trainData, scalers, hyperparams.knnK);
  }, [trainData, scalers, hyperparams.knnK]);

  // 3. Benchmark Comparison for Capstone Rubric
  const comparisonResults = useMemo(() => {
    return compareFoundationalModels(trainData, testData, scalers);
  }, [trainData, testData, scalers]);

  // 4. Test Predictions for Active Model
  const activeMetrics = useMemo(() => {
    const yTrue = testData.map((d: EmailRecord) => d.threat_class);
    let yProbs: number[] = [];

    if (activeModelType === 'logistic_regression') {
      yProbs = testData.map((d: EmailRecord) =>
        logisticModel.predictProbability(transformFeatures(d, scalers))
      );
    } else if (activeModelType === 'decision_tree') {
      yProbs = testData.map((d: EmailRecord) => decisionTreeModel.predictProbability(d));
    } else {
      yProbs = testData.map(
        (d: EmailRecord) => knnModel.predictProbability(transformFeatures(d, scalers)).prob
      );
    }

    const calculated = evaluatePredictions(yTrue, yProbs, threshold);
    calculated.trainSetSize = trainData.length;
    return calculated;
  }, [
    testData,
    trainData.length,
    activeModelType,
    logisticModel,
    decisionTreeModel,
    knnModel,
    scalers,
    threshold,
  ]);

  // Reset to default dataset
  const handleResetData = () => {
    setDataset(EMAIL_DATASET);
    setTrainRatio(0.75);
    setThreshold(0.5);
  };

  // Upload custom CSV handler
  const handleUploadCsv = (newRecords: EmailRecord[]) => {
    setDataset(newRecords);
  };

  // Re-train triggered from UI
  const handleRetrain = (params: {
    trainRatio: number;
    algorithm: ModelAlgorithm;
    lrEpochs?: number;
    treeDepth?: number;
    knnK?: number;
  }) => {
    setTrainRatio(params.trainRatio);
    setActiveModelType(params.algorithm);
    setHyperparams((prev) => ({
      lrEpochs: params.lrEpochs ?? prev.lrEpochs,
      treeDepth: params.treeDepth ?? prev.treeDepth,
      knnK: params.knnK ?? prev.knnK,
    }));
  };

  const threatCount = useMemo(() => {
    return dataset.filter((d) => d.threat_class === 1).length;
  }, [dataset]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Navigation & App Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenGlossary={() => setIsGlossaryOpen(true)}
        onOpenAiSummary={() => setIsAiSummaryOpen(true)}
        onResetData={handleResetData}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'eda' && (
          <DataExplorationTab dataset={dataset} onUploadCsv={handleUploadCsv} />
        )}

        {activeTab === 'training' && (
          <ModelTrainingTab
            trainData={trainData}
            testData={testData}
            trainRatio={trainRatio}
            setTrainRatio={setTrainRatio}
            activeModelType={activeModelType}
            setActiveModelType={setActiveModelType}
            onRetrain={handleRetrain}
            comparisonResults={comparisonResults}
            logisticModel={logisticModel}
            decisionTreeRoot={decisionTreeModel.root}
            scalers={scalers}
          />
        )}

        {activeTab === 'evaluation' && (
          <ModelEvaluationTab
            metrics={activeMetrics}
            modelName={
              activeModelType === 'logistic_regression'
                ? 'Logistic Regression'
                : activeModelType === 'decision_tree'
                ? 'Decision Tree (CART)'
                : 'K-Nearest Neighbors (KNN)'
            }
            threshold={threshold}
            setThreshold={setThreshold}
          />
        )}

        {activeTab === 'scanner' && (
          <LiveThreatScannerTab logisticModel={logisticModel} scalers={scalers} />
        )}

        {activeTab === 'capstone' && (
          <CapstoneReportTab
            metrics={activeMetrics}
            comparisonResults={comparisonResults}
            datasetSize={dataset.length}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-900 py-6 px-4 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-200">DataSight ML</span>
            <span>•</span>
            <span>Learn Depth Academy LLP Track 1 Capstone Project 05</span>
          </div>
          <div className="flex items-center gap-4 text-slate-500">
            <span>Zero-Cost Foundational ML</span>
            <span>•</span>
            <span>Explainable AI for Non-Technical Stakeholders</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <NonTechnicalGlossaryModal
        isOpen={isGlossaryOpen}
        onClose={() => setIsGlossaryOpen(false)}
      />

      <AiExecutiveSummaryModal
        isOpen={isAiSummaryOpen}
        onClose={() => setIsAiSummaryOpen(false)}
        datasetSize={dataset.length}
        threatCount={threatCount}
        metrics={activeMetrics}
        comparisonResults={comparisonResults}
      />
    </div>
  );
}
