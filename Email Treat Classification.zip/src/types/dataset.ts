export interface EmailRecord {
  id: string;
  subject: string;
  sender: string;
  recipient: string;
  message_length: number; // characters
  url_count: number;
  attachment_count: number;
  urgency_keywords: number; // count of urgency words (verify, urgent, suspended, invoice, crypto, password)
  suspicious_domain: number; // 0: legitimate domain, 1: typosquatted/free/suspicious
  display_name_mismatch: number; // 0: matching, 1: mismatched display name vs address
  has_executable_attachment: number; // 0: no, 1: yes (.exe, .scr, .zip, .vbs)
  threat_class: number; // 0: Routine / Safe, 1: Threat / Malicious
}

export type FeatureKey =
  | 'message_length'
  | 'url_count'
  | 'attachment_count'
  | 'urgency_keywords'
  | 'suspicious_domain'
  | 'display_name_mismatch'
  | 'has_executable_attachment';

export interface FeatureMetadata {
  key: FeatureKey;
  label: string;
  description: string;
  unit: string;
  type: 'numeric' | 'binary';
  min: number;
  max: number;
  step: number;
  nonTechnicalHelp: string;
}

export interface ConfusionMatrix {
  tp: number; // True Threat correctly blocked
  fp: number; // Safe email falsely blocked (False Alarm)
  tn: number; // Safe email correctly allowed
  fn: number; // Threat missed and let into inbox (Dangerous Leak)
}

export interface EvaluationMetrics {
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  rocAuc: number;
  confusionMatrix: ConfusionMatrix;
  testSetSize: number;
  trainSetSize: number;
}

export type ModelAlgorithm = 'logistic_regression' | 'decision_tree' | 'knn' | 'naive_bayes';

export interface ModelComparisonResult {
  algorithm: ModelAlgorithm;
  name: string;
  accuracy: number;
  precision: number;
  recall: number;
  f1Score: number;
  rocAuc: number;
  trainingTimeMs: number;
  interpretability: 'Very High' | 'High' | 'Moderate';
  suitabilityNote: string;
}

export interface FeatureImportance {
  feature: FeatureKey;
  label: string;
  weight: number;
  impact: 'increases_threat' | 'decreases_threat' | 'neutral';
  plainEnglishExplanation: string;
}

export interface ThreatPredictionResult {
  probability: number; // 0 to 1
  riskScore: number; // 0 to 100
  predictedClass: 0 | 1;
  verdict: 'Routine / Safe' | 'Suspicious' | 'Critical Threat';
  confidence: number;
  featureContributions: {
    feature: FeatureKey;
    label: string;
    value: number;
    contributionScore: number; // percentage or relative impact
    isHighRisk: boolean;
    explanation: string;
  }[];
  naturalSummary: string;
  suggestedAction: string;
}
